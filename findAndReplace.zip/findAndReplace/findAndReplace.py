#!/usr/bin/env python3
import os
import re
import docx2txt
import pathlib
import sys, os
from docx import Document



document = Document()

exe = sys.argv[0]
dname = os.path.dirname(exe)

dirName = dname + "/inputFiles"
textToFind = 'test'
textToReplace = 'test2'
sourcePath = os.listdir(dname +"/inputFiles/")
currentDirectory = dname
fileList = []
textList = []
nameList = []
fileNames = []
i = 0




# Cherche tous les documents dans les sous dossiers d'un dossier indiqué
def getListOfFiles(dirName):
    # create a list of file and sub directories
    # names in the given directory
    listOfFile = os.listdir(dirName)
    allFiles = list()
    allFiles2 = list()
    # Iterate over all the entries

    for entry in listOfFile:

        # Create full path
        fullPath = os.path.join(dirName, entry)
        if entry.lower().endswith('.docx'):
            fileNames.append(entry)
        # If entry is a directory then get the list of files in this directory
        if os.path.isdir(fullPath):
            allFiles = allFiles + getListOfFiles(fullPath)
        else:
            allFiles.append(fullPath)

    # enlève de la liste tous les documents qui ne finissent pas par ".docx"
    for file in allFiles:
        if file.lower().endswith('.docx'):
            allFiles2.append(file)

    allFiles = allFiles2
    return allFiles


def delete_paragraph(paragraph):
    p = paragraph._element
    p.getparent().remove(p)
    p._p = p._element = None


def atoi(text):
    return int(text) if text.isdigit() else text


def natural_keys(text):
    return [atoi(c) for c in re.split(r'(\d+)', text)]


# la première liste comprend tous les termes à chercher et la deuxième liste comprend
# les termes de remplacement.
searchList = ["testA", "testB", "testC"]

replaceList = ["test1", "test2", "test3"]

for dirname, dirnames, filenames in sorted(os.walk('inputFiles/')):
    # print path to all subdirectories first.
    for filename in filenames:
        # print(os.path.join(dirname, filename))
        filePath = currentDirectory + "/" + os.path.join(dirname, filename)

        # print(filename)

listOfFiles = getListOfFiles(dirName)

fileList.sort(key=natural_keys)
nameList.sort(key=natural_keys)
# print(fileList)
# print(nameList)

# Nombre de fichiers à remplacer
freq = 0
count = 0

#print("Files and names before sort : ")
#print(listOfFiles)
#print(fileNames)

listOfFiles.sort(key=natural_keys)
fileNames.sort(key=natural_keys)

#print("Files and names after sort : ")
#print(listOfFiles)
#print(fileNames)

# prend le path des éléments de la liste de fichiers et les tranforme en output path
outputList = [w.replace('inputFiles', 'outputFiles') for w in listOfFiles]
outputList2 = []
print("output list : ")
print(outputList)

for sourceFile in listOfFiles:
    if sourceFile.lower().endswith('.docx'):
        # print(sourceFile)
        text = docx2txt.process(sourceFile)

        # Tout est mis en minuscule pour faciliter la recherche (n'est plus d'actualité)
        #text = text.lower()

        # Regex Method
        for i in range(len(searchList) - 1):
            search = "(" + re.escape(searchList[i]) + ")" + r'\b'
            #print(search)
            text = re.sub(search, ("["+replaceList[i]+"]"), text,flags=re.IGNORECASE)
        # print(text)

        freq = sourceFile.count(textToFind)



        replace2 = ''
        fileNameList = []
        # crée tous les dossiers
        for i in range(len(outputList)):
            search2 = "\/Mod[0-9].*docx"
            # print(search)
            outputList[i] = re.sub(search2, replace2, outputList[i])
            fileNameList.append(re.findall('Mod[0-9].*docx', listOfFiles[i]))
            # outputList[i] = outputList2[i]

        #print(outputList)
        fileNameList = [item for elem in fileNameList for item in elem]
        pathlib.Path(outputList[count]).mkdir(parents=True, exist_ok=True)

        # document.add_heading(nameList[count], 0)
        section = document.sections[0]
        header = section.header

        paragraph = header.paragraphs[0]
        paragraph.text = fileNameList[count]

        p = document.add_paragraph(text)

        # sauvegarde tous les fichiers dans les dossiers déjà crées
        document.save(outputList[count] + "/" + fileNameList[count])

        delete_paragraph(p)
        header.is_linked_to_previous = True

        count += 1

        print('Total Records Replaced :' + str(count))
